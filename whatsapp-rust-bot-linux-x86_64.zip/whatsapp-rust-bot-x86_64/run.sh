#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
if [ ! -f .env ]; then
    cp .env.example .env
    printf '%s\n' 'أنشأت ملف .env من القالب.' 'أضف رقم واتساب الدولي في WHATSAPP_PHONE_NUMBER ثم شغّل ./run.sh مجددًا.' >&2
    exit 1
fi
exec ./whatsapp-rust-bot
